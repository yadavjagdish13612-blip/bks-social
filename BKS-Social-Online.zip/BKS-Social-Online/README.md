# BKS Social — Online Edition

This version is designed for multiple phones/users. It uses MongoDB Atlas for shared data and Cloudinary for photos/videos, so data is not tied to one phone's storage.

## Required online services
1. MongoDB Atlas — create a database and copy its connection string.
2. Cloudinary — create an account and copy cloud name, API key and API secret.

## Configure
Copy `.env.example` to `.env` and fill in:
- MONGODB_URI
- JWT_SECRET
- CLOUDINARY_CLOUD_NAME
- CLOUDINARY_API_KEY
- CLOUDINARY_API_SECRET

## Run
npm install
npm start

For phones to access it, deploy this Node app to a public HTTPS host. Then point the Android WebView/app to that HTTPS address.

## Features
Accounts, profiles, follow/following, photo/video posts, reels, likes, comments, sharing through the existing UI, marketplace listings, social links and real-time user chat.

## Important
This package is online-ready but not published. A public hosting URL and service credentials are intentionally not included.
